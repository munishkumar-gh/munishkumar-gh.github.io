# Utah Forge core and log data visualization. Simple Thermal Conductivity regression. Preliminar thermofacies definition. 
 
Well 58-32
Set of petrophysical logs, and cuttings sample laboratory results (XRD and Thermal Conductivity)
Data downloaded from https://gdr.openei.org/submissions/1111

Other references:
Energy and Geoscience Institute at the University of Utah. (2018). Utah FORGE: Logs and Data from Deep Well 58-32 (MU-ESW1)  [data set].  Retrieved from https://dx.doi.org/10.15121/1452735.

![Forge Logo](/images/forge_logo.jpg)

![Thermofacies](/images/thermofacies.png)
