### Raton Basin Colorado. Geothermal Data Collection. Preliminar Thermal Assessement from Oil an Gas Well Data

### MAIN GOALS

#### - Visualization of public geothermal data for Raton Basin 

#### - Extraction and analysis of public formation tops, electric logs, production data

#### - Classification of thermofacies using unsupervised machine learning algorithms 

#### - Build a geotermal conceptual model for the basin

#### - Geothermal economic assessment of the basin


        
        


